#include<stdio.h>
#include<stdlib.h>
int main()
{
    int n,i,c=0;
    printf("Enter a number :\n");
    scanf("%d",&n);
    for(i=2;i<n/2;i++){
    printf("\n n,%d  \t i,%d,\t remainder ; %d",n,i,n%i);
    if(n%i==0){
    c=1;
    break;
}
}
    if(c==0)
    {
      printf("Given number is prime number");
    }
    else
    {
        printf(" given number is not a prime");
    }}
